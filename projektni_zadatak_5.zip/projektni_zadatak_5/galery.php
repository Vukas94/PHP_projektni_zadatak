<?php
print '
    <h1>Galerija</h1>
    <div id="gallery">
        <figure id="1">
            <a href="news/Slika1.jpg" target="_blank">
                <img src="news/Slika1.jpg" alt="Rimac Nevera" title="Rimac-Nevera">
                <figcaption>Rimac Nevera i Buggati Chiron.</figcaption>
            </a>
        </figure>
        <figure id="2">
            <a href="news/Slika2.jpg" target="_blank">
                <img src="news/Slika2.jpg" alt="Rimac Nevera" title="Rimac-Nevera">
                <figcaption>Rimac Nevera, Chiron i Tycan</figcaption>
            </a>
        </figure>
        <figure id="3">
            <a href="news/Slika3.jpg" target="_blank">
                <img src="news/Slika3.jpg" alt="Rimac Nevera" title="Rimac-Nevera">
                <figcaption>Rimac Nevera u noćnoj vožnji.</figcaption>
            </a>
        </figure>
        <figure id="4">
            <a href="news/Slika4.jpg" target="_blank">
                <img src="news/Slika4.jpg" alt="Rimac Nevera" title="Rimac-Nevera">
                <figcaption>Rimac Nevera na mostu.</figcaption>
            </a>
        </figure>
        <figure id="5">
            <a href="news/Slika5.jpg" target="_blank">
                <img src="news/Slika5.jpg" alt="Rimac Nevera" title="Rimac-Nevera">
                <figcaption>Rimac Nevera ima "billionaire doors".</figcaption>
            </a>
        </figure>
        <figure id="6">
            <a href="news/Slika6.jpg" target="_blank">
                <img src="news/Slika6.jpg" alt="Rimac Nevera" title="Rimac-Nevera">
                <figcaption>Rimac Nevera odmara na plaži.</figcaption>
            </a>
        </figure>
        <figure id="7">
            <a href="news/Slika7.jpg" target="_blank">
                <img src="news/Slika7.jpg" alt="Rimac Nevera" title="Rimac-Nevera">
                <figcaption>Rimac Nevera u dobrom društvu.</figcaption>
            </a>
        </figure>
        <figure id="8">
            <a href="news/Slika8.jpg" target="_blank">
                <img src="news/Slika8.jpg" alt="Rimac Nevera" title="Rimac-Nevera">
                <figcaption>Nevera je jača od bure.</figcaption>
            </a>
        </figure>
        <figure id="9">
            <a href="news/Slika9.jpg" target="_blank">
                <img src="news/Slika9.jpg" alt="Rimac Nevera" title="Rimac-Nevera">
                <figcaption>Rimac Nevera x2.</figcaption>
            </a>
        </figure>
        <figure id="10">
            <a href="news/Slika10.jpg" target="_blank">
                <img src="news/Slika10.jpg" alt="Rimac Nevera" title="Rimac-Nevera">
                <figcaption>Rimac Nevera rear end.</figcaption>
            </a>
        </figure>
    </div>';
?>
